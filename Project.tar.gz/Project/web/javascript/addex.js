function addSection(subject){
    select = document.getElementById("addsubject");
    val = select.options[select.selectedIndex].value;
    sel = select.options[select.selectedIndex];

    if(val!=="none"){

        section='<div class="section" id="'+val+'" >\n' +
            '\n' +
            '    <h4>'+sel.innerHTML+'</h4><hr><br><label for="me1">Multiple Choice (only 1 answer): </label>\n' +
            '    <input class="type" name="'+val+' me1" id="me1" type="number" value="0"><br>\n' +
            '    <label for="meg1" >Multiple Choice (1 or more answers): </label>\n' +
            '    <input class="type" name="'+val+' meg1" id="meg1" type="number" value="0"> <br>\n' +
            '    <label  for="code" >Code</label>\n' +
            '    <input class="type" name="'+val+' code" id="code" type="number" value="0">\n<br>' +
            '    <label  for="article">Article</label>\n' +
            '    <input class="type" name="'+val+' article" id="article" type="number" value="0">\n<br>' +
            '<input type="button" onclick="remove(\''+val+'\')" value="remove subject">' +
            '</div>';
        sel.remove(sel.selectedIndex);
        document.getElementById("sections").innerHTML+=section;
    }
}
function count() {
    type = document.getElementsByClassName("type");
    var total = 0;
    for (var i = 0; i < type.length; ++i) {
        total += parseInt(type[i].value);
    }
    document.getElementsByName("total")[0].value = total;
}
function remove(val){

    var x = document.getElementById(val);
    x.outerHTML ="";
    select = document.getElementById("addsubject");
    option = document.createElement("option");
    option.text = val;
    option .value = val;
    select.add(option);
    delete x
}
define("ace/snippets/red",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText = " ";
exports.scope = "red";

});

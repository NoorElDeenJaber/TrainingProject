package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by njaber on 12/6/17.
 */
public class AddStudentsBean {
    private Connection conn;
    public AddStudentsBean(){
        try {
            Context envContext = new InitialContext();
            Context initContext = (Context) envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }
    }
    public void addStudentToExam(Long examID,int stdID){
        try {
            String query = "insert into student_exams values(?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setLong(1,examID);
            statement.setInt(2,stdID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

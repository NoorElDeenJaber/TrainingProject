package Models;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.*;
import java.util.Enumeration;

public class AddExamBean {
    private Connection conn;
    private HttpServletRequest req;
    PreparedStatement statement = null;
    String query = "";
    long curID;
    public AddExamBean(HttpServletRequest req) {
        this.req = req;
        Context envContext = null;
        try {
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    }
    void insertTypeCount(long id, String type, int total, String subject){

        try {
            query = "insert into type_count values(?,?,?,?)";
            statement = conn.prepareStatement(query);
            statement.setLong(1,id);
            statement.setString(2,type);
            statement.setInt(3,total);
            statement.setString(4,subject);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public long getID(){
        return curID;
    }
    void insertExams(String startdate,String starttime,int duration,int numOfQuestions){
        try {
            query = "insert into exams(date,time,duration,num_of_questions) values(?,?,?,?)";
            statement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,startdate);
            statement.setString(2,starttime);
            statement.setInt(3,duration);
            statement.setInt(4,numOfQuestions);
            statement.execute();
            ResultSet rs = statement.getGeneratedKeys();
            if(rs.next())
                curID = (long) rs.getObject(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addExam(){
        Enumeration names = req.getParameterNames();
        String startdate = req.getParameter((String) names.nextElement());
        String starttime = req.getParameter((String)names.nextElement());
        int duration = Integer.parseInt(req.getParameter((String) names.nextElement()));
        int numOfQuestions = Integer.parseInt(req.getParameter((String)names.nextElement()));
        insertExams(startdate,starttime,duration,numOfQuestions);
        names.nextElement();
        System.out.println(curID);
        while(names.hasMoreElements()){
            String name = (String) names.nextElement();
            String[] splited = name.split("\\s+");
            insertTypeCount(curID,splited[1],Integer.parseInt(req.getParameter(name)),splited[0]);
        }
    }
}

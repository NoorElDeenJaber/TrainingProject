package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.*;

public class AddQuestionBean {
    private HttpServletRequest req;
    private Connection conn;
        
    public AddQuestionBean(HttpServletRequest req) {
        this.req = req;
        try {
            Context envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void insertChoice(int j, String choice, int id){
        try {
            String query = "insert into Choices values(?,?,?);";
            //
            char c = (char)j;
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, String.valueOf(c));
            statement.setString(2,choice);
            statement.setInt(3,id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private int getCurID(){
        String query = "select MAX(id) from Questions ";
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    private void insertQuestion(){
        try {
            String description = req.getParameter("description");
            String type = req.getParameter("type");
            String subject = req.getParameter("subject");
            String query = "insert into Questions(description,type,subject) values(?,?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1,description);
            statement.setString(2,type);
            statement.setString(3,subject);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    private void insertAnswer(String ans, int qid){
        try {
            String query = "insert into answers values(?,?);";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, ans);
            statement.setInt(2,qid);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addQuestion() throws SQLException {
        insertQuestion();
        int id = getCurID();
        String[] choices = req.getParameterValues("desc");
        if(choices!=null) {
            for (int i = 0, j = 65; i < choices.length; ++i, ++j) {
                insertChoice(j, choices[i], id);
            }
        }
        String[] ans = req.getParameterValues("option");
        if(ans!=null) {
            for (int i = 0; i < ans.length; ++i) {
                insertAnswer(ans[i], id);
            }
        }
        conn.close();
    }
}

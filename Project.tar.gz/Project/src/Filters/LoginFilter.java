package Filters;

import Models.LoginBean;
import Models.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;

/**
 * Created by njaber on 11/26/17.
 */
public class LoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    public void forward(ServletRequest req,ServletResponse resp,String page,String message){
        try{
            RequestDispatcher rd = req.getRequestDispatcher(page);
            req.setAttribute("message",message);
            rd.forward(req,resp);
        } catch (ServletException | IOException e) {

            e.printStackTrace();
        }
    }
    private void loginProcess(ServletRequest req, ServletResponse resp, FilterChain filterChain){
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        HttpServletRequest hreq = (HttpServletRequest) req;
        HttpSession session = hreq.getSession();
        try {
            LoginBean login = new LoginBean(username,password);
            User user = login.validate();
            if(user!=null){
                User user2 = (User) session.getAttribute("user");
                System.out.println("Login Attempt from IP: "+req.getRemoteAddr()+":"+req.getRemotePort());
                if(!login.isLoggedIn(user.getId())||(user2!=null&&user.getId()==user2.getId())) {
                    session.setAttribute("user",user);
                    session.setAttribute("type",user.getType());
                    filterChain.doFilter(req, resp);
                }
                else{
                    forward(req,resp,"index.jsp","This user is currently logged in.");
                }
            }
            else{
                forward(req,resp,"index.jsp","Invalid username or password");
            }
        } catch (ClassNotFoundException | SQLException | ServletException | IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain){
        loginProcess(req,resp,filterChain);
    }
    @Override
    public void destroy() {

    }
}

package com.server;

import java.rmi.RemoteException;
import java.util.HashMap;

/**
 * Created by njaber on 12/17/17.
 */
public class ImplementTranslator implements Translator {

    private HashMap<String,String> dictionary;

    ImplementTranslator(){
        dictionary = new HashMap<>();
        fillDictionary();
    }

    @Override
    public String translateWord(String word) throws RemoteException {
        if(dictionary.containsKey(word))
            return dictionary.get(word);
        else
            return "Not Found";
    }
    @Override
    public String hearWord(String word) throws RemoteException {
        return "Currently saying the word: "+(word);
    }
    private void fillDictionary() {
        dictionary.put("Love","حب");
        dictionary.put("Moon","قمر");
        dictionary.put("Cat","قط");
        dictionary.put("Computer","حاسوب");
        dictionary.put("Friend","صديق");
        dictionary.put("Computer Science","علم الحب");
        dictionary.put("Book","كتاب");

    }
}

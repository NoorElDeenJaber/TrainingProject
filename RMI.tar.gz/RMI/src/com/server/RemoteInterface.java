package com.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by njaber on 12/17/17.
 */
public interface RemoteInterface extends Remote {
    void printMsg(String msg) throws RemoteException;

}

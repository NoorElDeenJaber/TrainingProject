package com.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by njaber on 12/17/17.
 */
public interface Translator extends Remote {
    String translateWord(String word) throws RemoteException;
    String hearWord(String word) throws RemoteException;
}

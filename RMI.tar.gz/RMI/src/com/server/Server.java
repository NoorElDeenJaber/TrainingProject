package com.server;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends RemoteImplementation{

    public static void main(String[] args) {
        try{
            RemoteImplementation obj = new RemoteImplementation();
            RemoteInterface stub = (RemoteInterface) UnicastRemoteObject.exportObject(obj,0);
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("RemoteInterface",stub);
            System.out.println("Server is ready");
        }catch (RemoteException | AlreadyBoundException e) {
            e.printStackTrace();
        }
    }
}

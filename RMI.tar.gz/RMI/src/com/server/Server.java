package com.server;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends ImplementTranslator {


    private static Registry getRegistry() throws RemoteException {
        try {
            // we will try to create a registry on port 1234.
            return LocateRegistry.createRegistry(1234);
        } catch (RemoteException e) {
            //if there is already an existing registry on that port we will get it.
            return LocateRegistry.getRegistry(1234);
        }
    }
    public static void main(String[] args) {
        try{

            //create the object we want to export.
            ImplementTranslator obj = new ImplementTranslator();

            //Export stub( proxy of our lovely object).
            Translator stub = (Translator) UnicastRemoteObject.exportObject(obj,1234);

            //get our beloved registry
            Registry registry = getRegistry();

            //Bind our stub to the registry.
            registry.bind("Translator",stub);

            //We're ready to accept requests.
            System.err.println("Server is ready");
        }catch (RemoteException | AlreadyBoundException e) {
            System.out.println("Server :" + e.getMessage());
        }
    }
}

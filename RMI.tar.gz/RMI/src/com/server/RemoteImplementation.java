package com.server;

import java.rmi.RemoteException;

/**
 * Created by njaber on 12/17/17.
 */
public class RemoteImplementation implements RemoteInterface {
    @Override
    public void printMsg(String msg) throws RemoteException {
        System.out.println("Msg: "+msg);
    }
}

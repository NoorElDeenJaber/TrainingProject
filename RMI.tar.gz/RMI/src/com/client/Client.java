package com.client;


import com.server.Translator;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

    public static void main(String[] args) {
	// write your code here
        Registry registry = null;
        try {
            registry = LocateRegistry.getRegistry(null,1234);
            // Looking up the registry for the remote object
            Translator stub = (Translator) registry.lookup("Translator");
            // Calling
            // the remote method using the obtained object
            System.out.println("**********");
            System.out.println(stub.translateWord("Love"));
            System.out.println("**********");
            System.out.println(stub.hearWord("Computer Science"));
        } catch (RemoteException | NotBoundException e) {
            e.printStackTrace();
        }

        // System.out.println("Remote method invoked");

    }
}

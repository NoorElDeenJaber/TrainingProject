package com.client;

import com.server.RemoteInterface;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Registry registry = null;
        try {

            registry = LocateRegistry.getRegistry(null);

            // Looking up the registry for the remote object
            RemoteInterface stub = (RemoteInterface) registry.lookup("Hello");

            // Calling the remote method using the obtained object
            stub.printMsg("Hello Server");
        } catch (RemoteException | NotBoundException e) {
            e.printStackTrace();
        }

        // System.out.println("Remote method invoked");

    }
}

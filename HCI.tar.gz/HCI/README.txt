A Pen created at CodePen.io. You can find this one at http://codepen.io/dghez/pen/Kwoper.

 Menu with dropdown made only in css, with a line that follow the hover on the line
package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by njaber on 12/6/17.
 */
public class ShowExamsBean {
    private Connection conn;
    public ShowExamsBean(){
        try {
            Context envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }
    }
    public List<Exam> getAllNotStartedExams() {
        List<Exam> exams = new ArrayList();
        PreparedStatement statement = null;
        try {
            String query = "select * from exams";
            statement = conn.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Exam exam = new Exam();
                exam.setId(rs.getInt(1));
                exam.setDate(rs.getString(2));
                exam.setTime(rs.getString(3));
                exam.setNumOfQuestions(rs.getInt(4));
                exam.setDuration(rs.getInt(5));
                DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");

                //all variables are in milli seconds
                long currentTime =  new Date().getTime();
                long examTime = 0;
                long duration = 0;
                examTime = format.parse(exam.getDate() + " " + exam.getTime()).getTime();
                duration = exam.getDuration() * 60000;
                long left = (long) duration - ((long) currentTime - (long) examTime);
                long minutes = (left/1000)/60;
                long seconds = (left%(1000*60)/1000);
                String timeLeft = "Finished";
                System.out.println(left+" "+minutes+" "+seconds);
                if(minutes>0)
                    timeLeft = minutes+"m : "+seconds+"s";

                exam.setTimeLeft(timeLeft);
                exam.setName(rs.getString(7));
                exam.setDescription(rs.getString(8));
                exams.add(exam);
            }
        } catch (SQLException | ParseException e) {
            e.printStackTrace();
        } finally {
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try{
                conn.close();
            }catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return exams;
    }
    public void close(){

    }
}

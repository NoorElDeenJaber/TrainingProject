package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by njaber on 12/6/17.
 */
public class StartExamBean {
    Connection conn;
    public StartExamBean(){
        try {
            Context envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }

    }
    public List<Exam> getAllNotStartedExams() {
        List<Exam> exams = new ArrayList();
        try {
            String query = "select * from exams where started = 0";
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Exam exam = new Exam();
                exam.setId(rs.getInt(1));
                exam.setDate(rs.getString(2));
                exam.setTime(rs.getString(3));
                exam.setDuration(rs.getInt(4));
                exam.setNumOfQuestions(rs.getInt(5));
                exams.add(exam);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exams;
    }
}

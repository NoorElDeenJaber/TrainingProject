package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by njaber on 12/6/17.
 */
public class AddStudentsBean {
    private Connection conn;

    public AddStudentsBean(){
        try {
            Context envContext = new InitialContext();
            Context initContext = (Context) envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) initContext.lookup("jdbc/training");
            conn = ds.getConnection();
            System.out.println("Connection established in adds bean");
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }


    }
    public ArrayList<User> getStudents(){
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement("select * from users where type = 2");
            ResultSet rs = statement.executeQuery();
            ArrayList<User> students = new ArrayList<>();
            while(rs.next()) {
                int id = rs.getInt(1);
                String username = rs.getString(2);
                String name = rs.getString(6);
                String email = rs.getString(5);
                String phoneNumber = rs.getString(7);
                User user = new User();
                user.setId(id);
                user.setUsername(username);
                user.setName(name);
                user.setEmail(email);
                user.setPhone(phoneNumber);
                students.add(user);
            }
            return students;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
    public void addStudentToExam(Long examID,int stdID){
        PreparedStatement statement = null;
        try {
            String query = "insert into student_exams(examid, stdid) values(?,?)";
            statement = conn.prepareStatement(query);
            statement.setLong(1,examID);
            statement.setInt(2,stdID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {

                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
    public void close(){
        try{
            conn.close();
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

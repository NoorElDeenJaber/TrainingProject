package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;

public class ShowExamInfoBean {
    private Connection conn = null;
    public ShowExamInfoBean(){
        Context envContext = null;
        try {
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<User> getStudents(int examid) {
        String query = "select * from student_exams left join users on student_exams.stdid = users.id  where student_exams.examid = ? ";
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(query);
            statement.setInt(1,examid);
            ResultSet rs = statement.executeQuery();

            ArrayList<User> users= new ArrayList<>();
            while(rs.next()){

                User user = new User();
                user.setId(rs.getInt(2));
                user.setUsername(rs.getString(5));
                user.setEmail(rs.getString(8));
                user.setName(rs.getString(9));
                user.setPhone(rs.getString(10));
                String query1 = "select total from grades where examid = ? and stdid = ?";


                PreparedStatement statement1 = conn.prepareStatement(query1);
                statement1.setInt(1,examid);
                statement1.setInt(2,user.getId());
                ResultSet rs1 = statement1.executeQuery();
                if(rs1.next()){
                    user.setGrade(rs1.getDouble(1));
                }
                else{
                    user.setGrade(0.0);
                }
                users.add(user);

            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    public void close(){
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

package Models;

/**
 * Created by njaber on 12/6/17.
 */
public class Exam {
    private int id;
    private String date;
    private String time;
    private int duration;
    private int numOfQuestions;
    private boolean started;
    private boolean on;
    private String name;
    private String description;
    private String timeLeft;

    public void setTimeLeft(String timeLeft) {
        this.timeLeft = timeLeft;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumOfQuestions(int numOfQuestions) {
        this.numOfQuestions = numOfQuestions;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setStarted(boolean started) {
        this.started = started;
    }

    public int getDuration() {
        return duration;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public int getId() {
        return id;
    }

    public int getNumOfQuestions() {
        return numOfQuestions;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
    public boolean getStarted(){
        return started;
    }
    public boolean getOn(){
        return this.on;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public String getTimeLeft() {
        return timeLeft;
    }
}

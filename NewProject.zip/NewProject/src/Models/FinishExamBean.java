package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FinishExamBean {
    Connection conn;

    public FinishExamBean(){
        try {
            Context envContext = new InitialContext();
            Context initContext = (Context) envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }

    }
    public void addAnswer(int examid,int userid, int qid, String answer){
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement("INSERT INTO students_answers VALUES(?,?,?,?)");
            stmt.setInt(1,examid);
            stmt.setInt(2,userid);
            stmt.setInt(3,qid);
            stmt.setString(4,answer);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                assert stmt != null;
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void invalidateExam(int examid, int stdid) {
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement("update student_exams set ison = 0 where student_exams.examid=? and student_exams.stdid = ?");
            statement.setInt(1,examid);
            statement.setInt(2,stdid);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try{
                conn.close();
            }catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }
}

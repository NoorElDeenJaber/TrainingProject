package Models;

public class FinishExamBean {

    void addAnswer(){

    }

}

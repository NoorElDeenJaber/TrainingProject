package Models;

import java.io.*;

public class CompilerBean {

    public void updateFileCode(String code) {
        try(FileOutputStream os = new FileOutputStream(new File("code.cpp"))) {
            os.write(code.getBytes(), 0, code.length());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateInputFile(String input) {
        try (FileOutputStream os = new FileOutputStream(new File("input.txt"))) {
                os.write(input.getBytes(), 0, input.length());
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
    public StringBuilder compileCode() {
        BufferedReader error = null;
        try {
            String command = "g++ -o code.bin code.cpp";
            Process p = Runtime.getRuntime().exec(command);
            error = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            String line;
            StringBuilder output = new StringBuilder();
            while ((line = error.readLine()) != null) {
                output.append(line.trim()).append("\n");
            }
            p.waitFor();
            p.destroy();

            return output;

        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                assert error != null;
                error.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return null;
    }
    public String runCodeAndGenerateOutput() {
        BufferedReader br = null;
        try {
            Process p1 = Runtime.getRuntime().exec("./code.bin");
            br = new BufferedReader(new InputStreamReader(p1.getInputStream()));
            String line = "";
            StringBuilder output = new StringBuilder();
            while ((line = br.readLine()) != null) {
                output.append(line.trim()).append("\n");
            }
            p1.waitFor();
            p1.destroy();
            return String.valueOf(output);

        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                assert br != null;
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return null;
    }
}

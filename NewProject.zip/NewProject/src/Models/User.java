package Models;

/**
 * Created by njaber on 11/28/17.
 */
public class User {
    private int type;
    private String email;
    private String name;
    private String phone;
    private final String username;
    private final String password;
    private int id;
    private Exam exam;
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    void setType(int val){
        type = val;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public void setId(int val){
        id = val;
    }

    public String getUsername(){
        return username;
    }

    public String getPassword(){
        return password;
    }

    public int getId(){
        return id;
    }

    public int getType() {
        return type;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public Exam getExam() {
        return exam;
    }
}

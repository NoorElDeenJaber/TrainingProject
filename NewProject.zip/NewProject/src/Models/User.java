package Models;

/**
 * Created by njaber on 11/28/17.
 */
public class User {
    private int type;
    private double grade;
    private String email;
    private String name;
    private String phone;
    private String username;
    private String password;
    private int id;
    private Exam exam;
    public User() {
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    void setType(int val){
        type = val;
    }

    public double getGrade() {
        return grade;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public void setId(int val){
        id = val;
    }

    public String getUsername(){
        return username;
    }

    public String getPassword(){
        return password;
    }

    public int getId(){
        return id;
    }

    public int getType() {
        return type;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public Exam getExam() {
        return exam;
    }
}

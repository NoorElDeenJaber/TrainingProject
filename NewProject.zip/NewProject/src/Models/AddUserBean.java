package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by njaber on 11/29/17.
 */
public class AddUserBean {
    private HttpServletRequest req;
    private Connection conn;

    public AddUserBean(HttpServletRequest req){
        try {
            this.req = req;
            Context envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }

    }
    public void add(){
        PreparedStatement stmt = null;
        try {

            stmt = conn.prepareStatement("insert into users(username,password,type,email,name,phone)" +
                    " values(?,?,?,?,?,?)");
            stmt.setString(1,req.getParameter("username"));
            stmt.setString(2,req.getParameter("password"));
            stmt.setString(3,req.getParameter("type"));
            stmt.setString(4,req.getParameter("email"));
            stmt.setString(5,req.getParameter("name"));
            stmt.setString(6,req.getParameter("phone"));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                assert stmt != null;
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try{
                conn.close();
            }catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }
}

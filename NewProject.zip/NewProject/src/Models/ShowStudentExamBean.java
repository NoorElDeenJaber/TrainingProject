package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

public class ShowStudentExamBean {

    static public int totalPts = 0;
    static public int total = 0;
    public HashMap<Integer, ExamBean.Question> getStudentExam(int examid, int stdid) {
        String query = "select * from Questions " +
                "LEFT JOIN students_answers " +
                "on students_answers.qid = Questions.id " +
                "where students_answers.examid = ? and students_answers.userid = ?";
        Context envContext = null;
        Connection conn = null;
        PreparedStatement statement = null;
        try {
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
            statement = conn.prepareStatement(query);
            statement.setInt(1,examid);
            statement.setInt(2,stdid);
            ResultSet rs = statement.executeQuery();
            HashMap<Integer,ExamBean.Question> questions = new HashMap<>();
            ExamBean.Question  temp = new ExamBean.Question();
           totalPts = 0;
           total = 0;
            while(rs.next()){
                ExamBean.Question  question = new ExamBean.Question();

                if(questions.containsKey(rs.getInt(1))) {
                    String answer = rs.getString(8);
                    System.out.println(answer);
                    List<String> ans = questions.get(rs.getInt(1)).answers;
                    ans.add(answer);
                    questions.get(rs.getInt(1)).answers = ans;
                }else {
                    question.id = rs.getInt(1);
                    question.description = rs.getString(2);
                    question.type = rs.getString(3);
                    String answer = rs.getString(8);
                    question.answers.add(answer);
                    String query1 = "select * from Choices where qid = ?";
                    PreparedStatement statement1 = conn.prepareStatement(query1);
                    statement1.setInt(1,question.id);
                    ResultSet rs1 = statement1.executeQuery();
                    while(rs1.next()){
                        question.choices.add(new ExamBean.Choice(rs1.getString(1),rs1.getString(2)));
                    }
                    query1 = "SELECT count(*) FROM answers LEFT JOIN students_answers ON answers.qid = students_answers.qid WHERE answers.answer = students_answers.answer AND answers.qid = ?";
                    statement1 = conn.prepareStatement(query1);
                    statement1.setInt(1,question.id);
                    rs1 = statement1.executeQuery();
                    rs1.next();
                    int eqNum = rs1.getInt(1);

                    query1 = "select count(*) from answers where qid=?";
                    statement1 = conn.prepareStatement(query1);
                    statement1.setInt(1,question.id);
                    rs1 = statement1.executeQuery();
                    rs1.next();
                    int correctNumber = rs1.getInt(1);
                    question.correct = correctNumber==eqNum;

                    query1 = "select * from answers where qid=?";
                    statement1 = conn.prepareStatement(query1);
                    statement1.setInt(1,question.id);
                    rs1 = statement1.executeQuery();
                    while(rs1.next()){
                        question.correctAnswers.add(rs1.getString(1));
                    }
                    question.correct = correctNumber==eqNum;
                    total++;
                    totalPts += (correctNumber==eqNum&&correctNumber!=0)?1:0;
                    questions.put(question.id,question);
                }
            }
            return questions;
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
        }
        finally {

            try {
                assert envContext != null;
                envContext.close();
            } catch (NamingException e) {
                e.printStackTrace();
            }
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}

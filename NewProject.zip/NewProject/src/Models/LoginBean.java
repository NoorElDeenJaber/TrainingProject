package Models; /**
 * Created by njaber on 11/26/17.
 */

import Controllers.LoginController;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class LoginBean {

    private Connection conn;
    private User user;
    public boolean isLoggedIn(int id) throws ClassNotFoundException, SQLException {
        return LoginController.shared.containsKey(id)&& LoginController.shared.get(id);
    }
    public LoginBean(String username, String password) throws ClassNotFoundException, SQLException {
        user = new User(username,password);
        Context envContext = null;
        try {
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException e) {
            e.printStackTrace();
        }
    }
    public User validate() throws SQLException {
        String query= "select * from users as user " +
                "left join student_exams as exam " +
                "on exam.stdid = user.id left join exams as e on e.id = exam.examid " +
                "where username = ? and password = ?";
        PreparedStatement stmt = conn.prepareStatement( query);
        stmt.setString(1, user.getUsername());
        stmt.setString(2, user.getPassword());
        ResultSet rs = stmt.executeQuery();
        if(rs.next()) {
            user.setId(rs.getInt(1));
            user.setType(rs.getInt(4));
            user.setEmail(rs.getString(5));
            user.setPhone(rs.getString(7));
            user.setName(rs.getString(6));
            Exam exam = new Exam();
            exam.setId(rs.getInt(8));
            exam.setDate(rs.getString(11));
            exam.setTime(rs.getString(12));
            exam.setStarted(rs.getBoolean(14));
            exam.setDuration(rs.getInt(15));
            user.setExam(exam);
            return user;
        }
        return null;
    }
}

package Models; /**
 * Created by njaber on 11/26/17.
 */

import Controllers.LoginController;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static Controllers.MainController.shared;

public class LoginBean {

    private Connection conn;
    private User user;
    public boolean isLoggedIn(int id) throws ClassNotFoundException, SQLException {
        return shared.containsKey(id)&& shared.get(id);
    }
    public LoginBean(String username, String password) throws ClassNotFoundException, SQLException {
        user = new User();
        user.setUsername(username);
        user.setPassword(password);

        Context envContext = null;
        try {
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException e) {
            e.printStackTrace();
        }

    }
    public User validate()  {
        String query= "select * from users as user " +
                "left join student_exams as exam " +
                "on exam.stdid = user.id left join exams as e on e.id = exam.examid " +
                "where username = ? and password = ?";
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement( query);
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                user.setId(rs.getInt(1));
                user.setType(rs.getInt(4));
                user.setEmail(rs.getString(5));
                user.setName(rs.getString(6));
                user.setPhone(rs.getString(7));
                Exam exam = new Exam();
                exam.setId(rs.getInt(8));
                exam.setOn(rs.getBoolean(10));
                exam.setDate(rs.getString(12));
                exam.setTime(rs.getString(13));
                exam.setNumOfQuestions(14);
                exam.setDuration(rs.getInt(15));
                exam.setStarted(rs.getBoolean(16));
                user.setExam(exam);
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try{
                conn.close();
            }catch (SQLException e) {
                e.printStackTrace();
            }

            try {
                assert stmt != null;
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}

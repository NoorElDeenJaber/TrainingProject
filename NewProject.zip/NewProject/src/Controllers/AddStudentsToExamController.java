package Controllers;

import Models.AddStudentsBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;

public class AddStudentsToExamController extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AddStudentsBean bean = new AddStudentsBean();
        Enumeration e = req.getParameterNames();
        Long curExamID = (Long) req.getSession().getAttribute("examid");
        while (e.hasMoreElements()){
            int w = Integer.parseInt((String) e.nextElement());
            bean.addStudentToExam(curExamID, w);
        }
        req.getRequestDispatcher("index.jsp").forward(req,resp);
        bean.close();
    }
}

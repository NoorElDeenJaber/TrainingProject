package Controllers;

import Models.CompilerBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

public class CompilerController extends HttpServlet {

    private String injectFreopen(String reqCode){
        StringBuilder code = new StringBuilder(reqCode);
        code.insert(0,"#include<stdio.h>\n");
        int ix = code.indexOf("int main()");
        int i=0;
        for(i=ix;i<code.length();++i){
            if(code.charAt(i)=='{'){
                break;
            }
        }
        code.insert(i+1,"\n    freopen (\"input.txt\",\"r\",stdin);");
        return code.toString();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        CompilerBean compilerBean = new CompilerBean();
        String rcode = injectFreopen(req.getParameter("code"));
        //lock this area to ensure thread safety
        synchronized (this) {
            compilerBean.updateFileCode(rcode);
            compilerBean.updateInputFile(req.getParameter("input"));

            String t = String.valueOf(compilerBean.compileCode());

            String output = compilerBean.runCodeAndGenerateOutput();
            if(!t.equals(""))
                output = String.valueOf(t);

            PrintWriter pw = resp.getWriter();
            //write output to response
            pw.write(output);
            pw.close();
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}


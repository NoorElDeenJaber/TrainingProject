package Controllers;

import Models.User;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import static Controllers.MainController.shared;

public class LoginController extends HttpServlet implements Servlet {

    String dispatcher = null;
    private void startSession(HttpServletRequest req) throws SQLException {
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println(req.getAttribute("islogin")+" controller islogin");
        doPost(req,resp);
        return dispatcher;
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) req.getAttribute("user");
        //     shared.put(user.getId(),true);
        //     startSession(req);
        switch (user.getType()) {
            case 1: dispatcher = "admin.jsp"; break;
            case 2: dispatcher ="exam";break;
            case 3: dispatcher ="instructor.jsp";break;
        }
        System.out.println("dispatcher "+dispatcher );
    }
}

package Controllers;

import Models.ExamBean;
import Models.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

public class ExamController extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ExamBean examBean = new ExamBean(req);
        HttpSession session = req.getSession();

        User user = (User) session.getAttribute("user");

        if(user!=null) {
            HashMap<String, ExamBean.Subject> x = examBean.getExam(user.getExam().getId());
            req.getSession().setAttribute("exam", x);
        }
        req.getRequestDispatcher("exam.jsp").forward(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }


}

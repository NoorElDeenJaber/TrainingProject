package Controllers;

import Models.FinishExamBean;
import Models.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;
import java.util.StringTokenizer;

import static Controllers.MainController.shared;

public class FinishExamController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Enumeration names = req.getParameterNames();
        FinishExamBean finishExamBean = new FinishExamBean();
        User user = (User) req.getSession().getAttribute("user");
        while(names.hasMoreElements()){
            String name = (String) names.nextElement();
            StringTokenizer tokenizer = new StringTokenizer(name," ");
            String qType = tokenizer.nextToken();
            if(qType.equals("me1")||qType.equals("meg1")){
                int qid = Integer.parseInt(tokenizer.nextToken());
                String answer = tokenizer.nextToken();
                finishExamBean.addAnswer(user.getExam().getId(),user.getId(),qid,answer);
            }else{
                int qid = Integer.parseInt(tokenizer.nextToken());
                String answer = req.getParameter(name);
                finishExamBean.addAnswer(user.getExam().getId(),user.getId(),qid,answer);
            }
        }
        finishExamBean.invalidateExam(user.getExam().getId(),user.getId());
        HttpSession session = req.getSession();
        shared.remove(user.getId());
        session.invalidate();
        RequestDispatcher dispatcher = req.getRequestDispatcher("exam_finished.jsp");
        dispatcher.forward(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }

}

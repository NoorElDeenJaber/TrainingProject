package Controllers;

import Models.ShowStudentExamBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ShowStudentExamController extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ShowStudentExamBean bean = new ShowStudentExamBean();
        int examid = Integer.parseInt(req.getParameter("examid"));
        int stdid = Integer.parseInt(req.getParameter("stdid"));

        req.getSession().setAttribute("stdExam",bean.getStudentExam(examid,stdid));
        req.setAttribute("totalPts",ShowStudentExamBean.totalPts);
        req.setAttribute("total",ShowStudentExamBean.total);
        req.getRequestDispatcher("show_student_exam.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}

package Controllers;

import Filters.LoginFilter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

@WebServlet("/main/*")
public class MainController extends HttpServlet {
    public static ConcurrentHashMap<Integer, Boolean> shared;
    @Override
    public void init() throws ServletException {
        shared = new ConcurrentHashMap<>();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("one" );
        String url = String.valueOf(req.getRequestURL());
        int lastIndexOf = url.lastIndexOf("/");
        String action = url.substring(lastIndexOf+1);
        String jspPage = "";

        if(action.equals("login")){
            req.setAttribute("islogin","true");
            LoginController loginController = new LoginController();
            jspPage = loginController.process(req,resp);
        }
        System.out.println(jspPage+" pagege");
        if(!jspPage.equals("")){
            req.getRequestDispatcher(jspPage).forward(req,resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}

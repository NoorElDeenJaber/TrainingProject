package Controllers;

import Models.GradesBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/grades")
public class GradesController extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        GradesBean bean = new GradesBean();
        int stdid = Integer.parseInt(req.getParameter("stdid"));
        int examid = Integer.parseInt(req.getParameter("examid"));

        double grade = Double.parseDouble(req.getParameter("grade"));
        System.out.println(stdid+" "+examid+" "+grade);
        bean.addGrade(stdid,examid,grade);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}

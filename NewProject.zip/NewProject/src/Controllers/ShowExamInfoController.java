package Controllers;

import Models.ShowExamInfoBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ShowExamInfoController extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println(req.getParameter("examid"));
        ShowExamInfoBean showExamInfoBean = new ShowExamInfoBean();
        req.getSession().setAttribute("students", showExamInfoBean.getStudents(Integer.parseInt(req.getParameter("examid"))));
        req.getRequestDispatcher("show_exam_info.jsp").forward(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}

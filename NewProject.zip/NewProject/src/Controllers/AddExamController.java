package Controllers;

import Models.AddExamBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class AddExamController extends HttpServlet {
    /**
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AddExamBean addExamBean = new AddExamBean(req);
        addExamBean.addExam();
        HttpSession session = req.getSession();
        addExamBean.close();
        session.setAttribute("examid",addExamBean.getID());

        RequestDispatcher requestDispatcher = req.getRequestDispatcher("addStudents");
        requestDispatcher.forward(req,resp);
    }

    /**
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}

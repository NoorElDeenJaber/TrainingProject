package Filters;

import Models.LoginBean;
import Models.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by njaber on 11/26/17.
 */
public class LoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }
    /**
     * @param req request
     * @param resp response
     * @param message display this message on index.jsp
     */
    private void forward(ServletRequest req, ServletResponse resp, String message){
        try{
            RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
            req.setAttribute("message",message);
            rd.forward(req,resp);
        } catch (ServletException | IOException e) {

            e.printStackTrace();
        }
    }
    /**
     * This method handles the login request and gives the right action to be performed.
     * @param req request
     * @param resp resp
     * @param filterChain filterChain
     */
    private void loginProcess(ServletRequest req, ServletResponse resp, FilterChain filterChain){
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        HttpServletRequest hreq = (HttpServletRequest) req;
        HttpSession session = hreq.getSession();
        try {
            //create a LoginBean object and pass to it a username and password
            LoginBean login = new LoginBean(username,password);
            //get user info
            User user = login.validate();
            System.out.println(user+" <<");
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");

            //all variables are in milli seconds
            long currentTime =  new Date().getTime();
            long examTime = 0;
            long duration = 0;
            hreq.setAttribute("user",user);
            if(user!=null){
                boolean isStudent = user.getType()==2;
                if(isStudent) {
                    try {
                        examTime = format.parse(user.getExam().getDate() + " " + user.getExam().getTime()).getTime();
                        duration = user.getExam().getDuration() * 60000;
                        //needed for exam timer.
                        session.setAttribute("time", currentTime);
                        session.setAttribute("examtime", examTime);
                        session.setAttribute("duration", duration);
                    }catch (Exception e){
                        forward(req, resp, "No exam assigned for this user.");
                    }
                }

                //I don't know why this Object is here but it is working :)
                User user2 = (User) session.getAttribute("user");
                System.out.println("Login Attempt from IP: "+req.getRemoteAddr()+":"+req.getRemotePort());

                boolean examStarted = (examTime<=currentTime&&currentTime<=examTime+duration);
                boolean isIncorrect = ((!examStarted||!user.getExam().getOn())&&isStudent);
                boolean notLoggedIn = !login.isLoggedIn(user.getId()) || (user2 != null && user.getId() == user2.getId());

                if(isIncorrect) {
                    boolean isEnded = currentTime>duration+examTime||!user.getExam().getOn();
                    if(isEnded){
                        forward(req,resp, "Exam has ended");
                    }
                    else
                        forward(req, resp, "Exam hasn't started  yet.");
                }
                else if (notLoggedIn) {
                    session.setAttribute("user", user);
                    session.setAttribute("type", user.getType());
                    System.out.println(user.getName()+" logged in");
                    filterChain.doFilter(req, resp);
                }
                else{
                    forward(req,resp, "This user is currently logged in.");
                }
            }
            else{
                forward(req,resp, "Invalid username or password");
            }
        } catch (ClassNotFoundException | SQLException | ServletException | IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException {
        System.out.println(req.getAttribute("islogin")+ " FILTER");
        loginProcess(req, resp, filterChain);
    }
    @Override
    public void destroy() {

    }
}

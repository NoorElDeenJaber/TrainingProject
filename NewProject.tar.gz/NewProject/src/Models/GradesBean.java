package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class GradesBean {

    public void addGrade(int stdid, int examid, double grade) {
        String query = "INSERT INTO grades VALUES(?,?,?)";
        Context envContext = null;
        Connection conn = null;
        PreparedStatement statement = null;
        try {
            envContext = new InitialContext();
            Context initContext = (Context) envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource) initContext.lookup("jdbc/training");
            conn = ds.getConnection();
            statement = conn.prepareStatement(query);
            statement.setDouble(1,grade);
            statement.setInt(2,examid);
            statement.setInt(3,stdid);
            statement.executeUpdate();
        } catch (SQLException | NamingException e) {
            query = "update grades set total = ? where stdid = ? and examid=?";
            try {
                assert conn != null;
                statement = conn.prepareStatement(query);
                statement.setDouble(1,grade);
                statement.setInt(2,stdid);
                statement.setInt(3,examid);
                statement.executeUpdate();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
        finally {
            try {
                assert conn != null;
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                assert statement != null;
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

package Models;

/**
 * Created by njaber on 12/6/17.
 */
public class Exam {
    private int id;
    private String date;
    private String time;
    private int duration;
    private int numOfQuestions;
    private boolean started;

    public void setDate(String date) {
        this.date = date;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumOfQuestions(int numOfQuestions) {
        this.numOfQuestions = numOfQuestions;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setStarted(boolean started) {
        this.started = started;
    }

    public int getDuration() {
        return duration;
    }

    public int getId() {
        return id;
    }

    public int getNumOfQuestions() {
        return numOfQuestions;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
    public boolean getStarted(){
        return started;
    }
}

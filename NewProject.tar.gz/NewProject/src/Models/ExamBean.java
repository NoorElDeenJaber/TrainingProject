package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExamBean {
    private Connection conn;
    private HttpServletRequest req;
    static class Types{
        int me1 ,meg1 ,code ,article;
        Types(){
            me1 = 0;
            meg1 = 0;
            code = 0;
            article = 0;
        }
    }
    public static class Question{
        String description;
        String type;
        int id;
        List<Choice> choices;
        Question(){
            choices = new ArrayList<>();
        }

        public List<Choice> getChoices() {
            return choices;
        }

        public String getDescription() {
            return description;
        }

        public String getType() {
            return type;
        }
        public int getId(){
            return id;
        }
    }
    private List<Question> getAllQuestions(String type,String subject,int count){
        try {
            List<Question> questions = new ArrayList<>();
            String query = "select * from Questions  where Questions.type = ? and Questions.subject = ? order by rand() limit ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1,type);
            statement.setString(2,subject);
            statement.setInt(3,count);

            ResultSet rs = statement.executeQuery();
            while(rs.next()){

                String query2 = "select * from Choices where qid = ?";
                PreparedStatement statement1 = conn.prepareStatement(query2);
                statement1.setInt(1,rs.getInt(1));
                ResultSet rs2 = statement1.executeQuery();
                Question question = new Question();
                question.id = rs.getInt(1);
                question.description = rs.getString(2);
                question.type = rs.getString(3);
                while(rs2.next()){
                    question.choices.add(new Choice(rs2.getString(1),rs2.getString(2)));
                }
                questions.add(question);
            }
            return questions;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static class Subject{
        private List<Question> me1;
        private List<Question> meg1;
        private List<Question> c;
        public List<Question> a;
        public List<Question> getMe1(){
            return me1;
        }
        public List<Question> getMeg1(){
            return meg1;
        }
        public List<Question> getC(){
            return c;
        }
        public List<Question> getA(){
            return a;
        }

        Subject(){
            me1 = new ArrayList<>();
            meg1 = new ArrayList<>();
            c = new ArrayList<>();
            a = new ArrayList<>();
        }

    }
    public static class Choice{
        String id;
        String description;
        Choice(String id,String description){
            this.id = id;
            this.description = description;
        }

        public String getDescription() {
            return description;
        }

        public String getId() {
            return id;
        }
    }

    public ExamBean(HttpServletRequest req){
        Context envContext = null;
        try {
            this.req = req;
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/training");
            conn = ds.getConnection();
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    }
    public HashMap<String, Subject> getExam(int id) {
        try {

            HashMap<String,Types> counter = new HashMap<>();
            String query = "select * from type_count where exam_id = ?";

            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1,id);
            ResultSet rs = statement.executeQuery();
            Types t = new Types();

            while(rs.next()){
                String subject = rs.getString(4);
                int count = rs.getInt(3);
                String type = rs.getString(2);
                if(!counter.containsKey(subject))
                    counter.put(subject,t);
                switch (type) {
                    case "me1":
                        counter.get(subject).me1 = count;
                        break;
                    case "meg1":
                        counter.get(subject).meg1 = count;
                        break;
                    case "c":
                        counter.get(subject).code = count;
                        break;
                    default:
                        counter.get(subject).article = count;
                        break;
                }
                Types types = new Types();
                types.article = counter.get(subject).article;
                types.code = counter.get(subject).code;
                types.me1 = counter.get(subject).me1;
                types.meg1 = counter.get(subject).meg1;
                counter.put(subject,types);
            }
            List<String> subjectsNames = new ArrayList<>();
            req.getSession().setAttribute("subjectsNames",subjectsNames);
            HashMap<String,Subject> subjects = new HashMap<>();
            counter.forEach((String key, Types value) -> {
                Subject subject = new Subject();
                subject.me1 = getAllQuestions("me1",key,value.me1);
                subject.c = getAllQuestions("c",key,value.code);
                subject.meg1 = getAllQuestions("meg1",key,value.meg1);
                subject.a = getAllQuestions("a",key,value.article);
                subjects.put(key,subject);
            });
            return subjects;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

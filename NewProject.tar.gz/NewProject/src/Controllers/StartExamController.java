package Controllers;

import Models.Exam;
import Models.StartExamBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by njaber on 12/6/17.
 */
public class StartExamController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StartExamBean bean = new StartExamBean();
        List<Exam> exams = bean.getAllNotStartedExams();
        request.setAttribute("exams",exams);
        getServletContext().getRequestDispatcher("/start_exam.jsp").forward(request,response);
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}

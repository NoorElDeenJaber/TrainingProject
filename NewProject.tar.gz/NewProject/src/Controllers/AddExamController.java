package Controllers;

import Models.AddExamBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class AddExamController extends HttpServlet {
    /**
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req,resp);
    }

    /**
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req,resp);
    }

    public String process(HttpServletRequest req, HttpServletResponse resp) {
        AddExamBean addExamBean = new AddExamBean(req);
        addExamBean.addExam();
        HttpSession session = req.getSession();
        addExamBean.close();
        session.setAttribute("examid",addExamBean.getID());
        return "/main/get_all_students";
    }
}

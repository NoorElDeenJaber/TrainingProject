package Controllers;

import Models.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class LoginController extends HttpServlet implements Servlet {
    public static ConcurrentHashMap<Integer, Boolean> shared;
    @Override
    public void init() throws ServletException {
          shared = new ConcurrentHashMap<>();
    }
    private void startSession(HttpServletRequest req) throws SQLException {
        HttpSession session = req.getSession(true);
        User user = (User) session.getAttribute("user");
        shared.put(user.getId(),true);
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            startSession(req);
            RequestDispatcher dispatcher = null;
            HttpSession session = req.getSession();
            User user = (User) session.getAttribute("user");
            switch (user.getType()) {
                case 1: dispatcher = req.getRequestDispatcher("admin.jsp");break;
                case 2: dispatcher = req.getRequestDispatcher("exam");break;
                case 3: dispatcher = req.getRequestDispatcher("instructor.jsp");break;
            }
            assert dispatcher != null;
            dispatcher.forward(req,resp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            doGet(req,resp);
    }
}

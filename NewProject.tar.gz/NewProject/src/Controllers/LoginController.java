package Controllers;
import Models.User;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

import static Controllers.MainController.shared;

    public class LoginController extends HttpServlet implements Servlet {
    @Override
    public void init() throws ServletException {
    }
    private void startSession(HttpServletRequest req) throws SQLException {
        HttpSession session = req.getSession(true);
        User user = (User) session.getAttribute("user");
        shared.put(user.getId(),true);
    }
    public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String dispatcher = null;
        try {
            startSession(req);
            HttpSession session = req.getSession();
            User user = (User) session.getAttribute("user");
            switch (user.getType()) {
                case 1: dispatcher = "/admin.jsp"; break;
                case 2: dispatcher ="main/exam";break;
                case 3: dispatcher ="/instructor.jsp";break;
            }
            return dispatcher;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req,resp);
    }
}
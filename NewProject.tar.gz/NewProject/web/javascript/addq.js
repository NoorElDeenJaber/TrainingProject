var e = document.getElementById("type");
function print(val){

    switch (val){
        case "me1": show_me("me1");break;
        case "meg1":show_me("meg1");break;
        default:
            document.getElementById("addhere").innerHTML = "";
    }
}
cur = 65;
function show_me(type){
    typ = document.getElementById("addhere");
    typ.innerHTML="";
    cur = 65;
    var t;
    if(type==="me1") t = "radio";
    else t = "checkbox";
    onc = "add('"+t+"')";
    $('#addhere').append('<button id ="addv" type="button" onclick="'+onc+'" > <i class="fa fa-plus-circle"></i></button>');
}
function add(type){

    $('#addhere').append('<input type="'+type+'" style="float:left" name="option" value="'+String.fromCharCode(cur)+'">');
    $('#addhere').append('<input style="float:right" placeholder="'+String.fromCharCode(cur)+'" type="text" name = "desc" id="'+String.fromCharCode(cur)+'" required/>'+'<br>');
    cur++;
    //typ.innerHTML+=option;
}
